<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class BattleRepository extends EntityRepository
{
}
